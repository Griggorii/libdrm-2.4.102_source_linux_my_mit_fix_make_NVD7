Griggorii@gmail.com


sudo apt --reinstall install libcunit1-dev valgrind xsltproc libcairo2-dev libpciaccess-dev -y

sudo apt --reinstall install libelf-dev flex bison build-essential libc-dev libc6-dev gcc g++ dpkg-dev bc fakeroot libncurses5-dev libssl-dev git make meson ninja-build -y

________________________________________________________________________________________________

make variant

patch -p1 < 01_default_perms.diff && ./configure --prefix=/usr --exec_prefix=/usr --libdir=/usr/lib/x86_64-linux-gnu --includedir=/usr/include && make -j16 && sudo make install

________________________________________________________________________________________________

Ninja dump not compile test install variant

cd build && ninja install

_________________________________________________________________________________________________

meson vartiant recompile

patch -p1 < 01_default_perms.diff && cd build && meson --reconfigure --prefix=/usr --libdir=/usr/lib/x86_64-linux-gnu --includedir=/usr/include -Dudev=true -Domap=true -Dexynos=true -Dfreedreno=true -Dtegra=true -Dvc4=true -Detnaviv=true && ninja install

and delete build

patch -p1 < 01_default_perms.diff && rm -rf build && mkdir build && cd build && meson --prefix=/usr --libdir=/usr/lib/x86_64-linux-gnu --includedir=/usr/include -Dudev=true -Domap=true -Dexynos=true -Dfreedreno=true -Dtegra=true -Dvc4=true -Detnaviv=true && ninja install

_________________________________________________________________________________________________

Deb package command

dpkg-buildpackage -rfakeroot -b

and

dpkg-buildpackage -rfakeroot -b -d

